import { base44 } from './base44Client';


export const mercadoPago = base44.functions.mercadoPago;

export const productScan = base44.functions.productScan;

